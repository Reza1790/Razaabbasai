# RAZA AI ASSISTANT (native Android, Kotlin + Jetpack Compose)

Min Android 8.0 (API 26) · target/compile SDK 34 · Kotlin 2.0.20 · AGP 8.5.2 · Gradle 8.7

## Build a debug APK
**Android Studio (easiest)**
1. Install Android Studio (Koala or newer; it bundles JDK 17) and the Android SDK Platform 34 from SDK Manager.
2. File → Open → select this `RazaAIAssistant` folder. Let Gradle sync (needs internet the first time).
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

**Command line**
```
cd RazaAIAssistant
gradle wrapper --gradle-version 8.7     # one-time, generates ./gradlew (needs a local Gradle install)
./gradlew assembleDebug
```
(Set `ANDROID_HOME` or create `local.properties` with `sdk.dir=/path/to/Android/Sdk`.)

## Install on a phone
- USB: enable Developer options → USB debugging, then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
- Or copy the APK to the phone, open it, and allow "Install unknown apps" for your file manager/browser.

## First run
Settings → Add provider → pick a preset → paste your API key → "Test connection & fetch models" → Save → pick a model from the chip at the top of the chat.
- **Gemini**: official endpoint is prefilled; key goes in the `x-goog-api-key` header.
- **OpenAI / custom**: any HTTPS endpoint implementing `POST {base}/chat/completions` with streaming (base usually ends in `/v1`).
- **CodeCraft**: no endpoint is bundled. Enter the base URL from CodeCraft's docs. It works only if CodeCraft is OpenAI-compatible; otherwise an adapter is required.

## What is implemented
Streaming chat (stop / regenerate / copy / read aloud), Markdown + code blocks with copy, chat history (search, rename, delete), six tool profiles (Assistant, Coding, Documents, Image, Study, Writing — each is a system-prompt profile on the selected model), image/PDF/text attachments, voice input (system speech recognizer), voice output (Android TTS), Urdu/Roman Urdu/English reply control, auto model fallback, dark/light/system theme, Keystore-encrypted API keys.

## Known limits (honest list)
- Not compiled or run in the environment that generated it (no Android SDK/network there). Expect to fix small compile errors on first sync.
- PDFs work only for providers marked "accepts PDFs" (Gemini preset). Word/Excel files are rejected. Image support depends on the model you choose.
- Plain `http://` endpoints are blocked (cleartext disabled); LAN servers need HTTPS or a manifest change.
- Voice input uses the Google/system recognizer (audio handled by that service); Urdu TTS requires an installed Urdu voice.
- Keys on-device are not server-side secrets. Use a backend for protected credentials.
- Tables in Markdown aren't rendered; headings, lists, bold, inline code and code blocks are.
