# Add project specific ProGuard rules here (release minify is disabled by default).
