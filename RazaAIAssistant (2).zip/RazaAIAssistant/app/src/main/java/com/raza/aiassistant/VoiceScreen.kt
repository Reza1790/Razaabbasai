package com.raza.aiassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private enum class VState { Idle, Listening, Thinking, Speaking }

/**
 * Hands-free voice conversation: listen -> send to the selected model -> speak the answer -> listen again.
 * Uses Android's SpeechRecognizer (needs the microphone permission) and TextToSpeech.
 * It only works while this screen is open (there is no always-on "Hey RAZA" wake word).
 */
@Composable
fun VoiceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val cs = MaterialTheme.colorScheme
    var state by remember { mutableStateOf(VState.Idle) }
    var heard by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }
    var level by remember { mutableFloatStateOf(0f) }
    var loop by remember { mutableStateOf(true) }
    var silent by remember { mutableIntStateOf(0) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null
    }

    fun micGranted() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun start() {
        val r = recognizer
        if (r == null) { info = "Speech recognition isn't available on this device (install/enable the Google app)."; state = VState.Idle; return }
        if (!micGranted()) { info = "Microphone permission is needed."; state = VState.Idle; return }
        vm.tts.stop()
        heard = ""; info = null; state = VState.Listening
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (vm.settings.voiceLang == "ur") "ur-PK" else "en-US")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.cancel()
        r.startListening(i)
    }

    fun retryOrIdle() {
        if (loop && silent < 2) {
            silent++
            handler.postDelayed({ if (state == VState.Listening) start() }, 400)
        } else { state = VState.Idle; silent = 0 }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) start() else info = "Microphone permission denied. Enable it in Android Settings → Apps → RAZA AI ASSISTANT → Permissions."
    }

    fun onTap() {
        when (state) {
            VState.Idle -> if (micGranted()) start() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
            VState.Listening -> recognizer?.stopListening()
            VState.Speaking -> { vm.tts.stop(); start() }
            VState.Thinking -> { vm.stop(); state = VState.Idle }
        }
    }

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        vm.newChat()          // each voice session is its own chat in your history
        vm.voiceMode = true
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() { silent = 0 }
            override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
            }
            override fun onResults(b: Bundle?) {
                level = 0f
                val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isEmpty()) { retryOrIdle(); return }
                silent = 0; heard = text; state = VState.Thinking
                vm.send(text)
            }
            override fun onError(code: Int) {
                level = 0f
                when (code) {
                    SpeechRecognizer.ERROR_CLIENT -> {}
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retryOrIdle()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> handler.postDelayed({ if (state == VState.Listening) start() }, 500)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { info = "Microphone permission is needed."; state = VState.Idle }
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> { info = "Speech recognition needs an internet connection."; state = VState.Idle }
                    else -> { info = "Couldn't hear you (error $code). Tap the orb to try again."; state = VState.Idle }
                }
            }
        })
        onDispose {
            view.keepScreenOn = false
            handler.removeCallbacksAndMessages(null)
            recognizer?.destroy()
            vm.tts.stop()
            vm.voiceMode = false
        }
    }

    // When the model finishes answering, speak the reply, then listen again (if continuous mode is on).
    LaunchedEffect(vm.streaming, vm.current?.messages?.size) {
        if (state == VState.Thinking && !vm.streaming) {
            val last = vm.current?.messages?.lastOrNull()
            if (last != null && last.role == "assistant") {
                reply = last.text
                if (last.isError) { info = last.text; state = VState.Idle }
                else {
                    state = VState.Speaking
                    val err = vm.tts.speak(last.text, vm.settings.voiceLang) {
                        if (state == VState.Speaking) { if (loop) start() else state = VState.Idle }
                    }
                    if (err != null) { info = err; state = VState.Idle }
                }
            }
        }
    }

    val t = rememberInfiniteTransition(label = "speak")
    val speakPulse by t.animateFloat(0.25f, 0.9f, infiniteRepeatable(tween(450), RepeatMode.Reverse), label = "sp")
    val target = when (state) { VState.Listening -> level; VState.Speaking -> speakPulse; VState.Thinking -> 0.5f; VState.Idle -> 0f }
    val energy by animateFloatAsState(target, tween(150), label = "energy")
    val name = vm.settings.assistantName.ifBlank { "RAZA" }
    val status = when (state) {
        VState.Idle -> "Tap the orb to talk"
        VState.Listening -> "Listening…"
        VState.Thinking -> "Thinking…"
        VState.Speaking -> "Speaking… tap to interrupt"
    }

    Box(Modifier.fillMaxSize().background(appBackground())) {
        Starfield(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.Close, "Close voice assistant") }
                Text(
                    name.uppercase(), Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = TextStyle(brush = Raza.Brand, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                )
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTap() }) {
                AiOrb(300.dp, energy)
            }
            Text(status, color = cs.primary, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            if (heard.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("“$heard”", textAlign = TextAlign.Center, color = cs.onSurface, style = TextStyle(textDirection = TextDirection.Content, fontSize = 16.sp))
            }
            info?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = cs.error, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.weight(1f))
            if (reply.isNotBlank()) {
                Box(Modifier.fillMaxWidth().heightIn(max = 150.dp).glass()) {
                    Text(
                        reply, color = cs.onSurface, fontSize = 14.sp,
                        style = TextStyle(textDirection = TextDirection.Content, fontSize = 14.sp),
                        modifier = Modifier.verticalScroll(rememberScrollState()).padding(14.dp)
                    )
                }
                Spacer(Modifier.height(14.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Continuous conversation", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Listens again after each reply", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
                Switch(loop, { loop = it })
                Spacer(Modifier.width(14.dp))
                GlowButton(onClick = { onTap() }, size = 68.dp) {
                    Icon(
                        if (state == VState.Idle) Icons.Filled.Mic else Icons.Filled.Stop,
                        if (state == VState.Idle) "Start talking" else "Stop", Modifier.size(30.dp), tint = Color.White
                    )
                }
            }
        }
    }
}
