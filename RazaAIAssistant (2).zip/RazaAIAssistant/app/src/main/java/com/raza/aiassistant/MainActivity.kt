package com.raza.aiassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            val dark = when (vm.settings.theme) {
                "light" -> false
                "system" -> isSystemInDarkTheme()
                else -> true
            }
            DisposableEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            RazaTheme(dark) {
                var screen by rememberSaveable { mutableStateOf("chat") }
                BackHandler(enabled = screen != "chat") { screen = "chat" }
                AnimatedContent(
                    targetState = screen,
                    transitionSpec = { (fadeIn(tween(250)) + slideInHorizontally(tween(250)) { it / 8 }) togetherWith fadeOut(tween(150)) },
                    label = "screen"
                ) { s ->
                    when (s) {
                        "chat" -> ChatScreen(vm, openSettings = { screen = "settings" }, openVoice = { screen = "voice" })
                        "settings" -> SettingsScreen(vm) { screen = "chat" }
                        else -> VoiceScreen(vm) { screen = "chat" }
                    }
                }
            }
        }
    }
}
