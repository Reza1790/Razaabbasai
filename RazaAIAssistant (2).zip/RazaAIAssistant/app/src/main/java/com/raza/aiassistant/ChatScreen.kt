package com.raza.aiassistant

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(vm: AppViewModel, openSettings: () -> Unit, openVoice: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var input by rememberSaveable { mutableStateOf("") }
    var showModels by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(vm.notice) {
        vm.notice?.let { snack.showSnackbar(it); vm.notice = null }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addAttachments(it) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val s = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!s.isNullOrBlank()) input = (input + " " + s).trim()
        }
    }
    fun startMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (vm.settings.voiceLang == "ur") "ur-PK" else "en-US")
        try { speech.launch(i) } catch (e: ActivityNotFoundException) {
            vm.notice = "No speech-recognition service found. Install/enable the Google app or another speech service."
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = { HistoryDrawer(vm, onClose = { scope.launch { drawerState.close() } }, openSettings = openSettings) }
    ) {
        Box(Modifier.fillMaxSize().background(appBackground())) {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(snack) },
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(vm.current?.title ?: "RAZA AI", fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Surface(
                                    onClick = { showModels = true }, shape = RoundedCornerShape(50),
                                    color = cs.primary.copy(alpha = 0.14f), modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Row(Modifier.padding(horizontal = 10.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Memory, null, Modifier.size(13.dp), tint = cs.primary)
                                        Spacer(Modifier.width(5.dp))
                                        Text(vm.modelLabel, fontSize = 12.sp, color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        },
                        navigationIcon = { IconButton({ scope.launch { drawerState.open() } }) { Icon(Icons.Filled.Menu, "Chat history") } },
                        actions = {
                            IconButton(openVoice) { Icon(Icons.Filled.GraphicEq, "Voice assistant", tint = cs.primary) }
                            IconButton({ vm.newChat() }) { Icon(Icons.Filled.Add, "New chat") }
                            IconButton(openSettings) { Icon(Icons.Filled.Settings, "Settings") }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    val chat = vm.current
                    val msgs = chat?.messages.orEmpty()
                    val live = vm.streaming && chat != null && vm.streamingChatId == chat.id
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (msgs.isEmpty() && !live) {
                            Starfield(Modifier.fillMaxSize())
                            EmptyState(vm, openSettings)
                        } else {
                            val listState = rememberLazyListState()
                            LaunchedEffect(msgs.size) { listState.animateScrollToItem(0) }
                            val lastAssistantId = msgs.lastOrNull { it.role == "assistant" }?.id
                            LazyColumn(
                                state = listState, reverseLayout = true, modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                if (live) item(key = "live") { LiveBubble(vm.streamText) }
                                if (!live && !vm.streaming && msgs.lastOrNull()?.role == "user") {
                                    item(key = "gen") { TextButton({ vm.regenerate() }) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Generate reply") } }
                                }
                                items(msgs.asReversed(), key = { it.id }) { m ->
                                    FadeSlideIn(fresh = System.currentTimeMillis() - m.time < 2500) {
                                    MessageBubble(
                                        m, isLast = m.id == lastAssistantId && !vm.streaming && msgs.last().id == m.id,
                                        onCopy = { clipboard.setText(AnnotatedString(m.text)); vm.notice = "Copied" },
                                        onSpeak = { vm.speak(m.text) },
                                        onRegenerate = { vm.regenerate() }
                                    )
                                    }
                                }
                            }
                        }
                    }

                    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(Tool.entries) { t ->
                            FilterChip(
                                selected = vm.tool == t, onClick = { vm.selectTool(t) }, label = { Text(t.label) },
                                leadingIcon = { Icon(t.icon, null, Modifier.size(16.dp)) }
                            )
                        }
                    }

                    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
                        if (vm.pending.isNotEmpty()) {
                            LazyRow(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(vm.pending) { a -> AttachmentPreview(a) { vm.removePending(a) } }
                            }
                        }
                        Row(verticalAlignment = Alignment.Bottom) {
                            IconButton({ filePicker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.AttachFile, "Attach files", tint = cs.onSurfaceVariant) }
                            OutlinedTextField(
                                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                                placeholder = { Text("Message RAZA AI…") }, shape = RoundedCornerShape(24.dp), maxLines = 6,
                                textStyle = TextStyle(textDirection = TextDirection.Content, fontSize = 16.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = cs.primary, unfocusedBorderColor = cs.outline,
                                    focusedContainerColor = cs.surface.copy(alpha = 0.9f), unfocusedContainerColor = cs.surface.copy(alpha = 0.8f)
                                )
                            )
                            IconButton({ startMic() }) { Icon(Icons.Filled.Mic, "Voice input", tint = cs.onSurfaceVariant) }
                            val canSend = input.isNotBlank() || vm.pending.isNotEmpty()
                            GlowButton(
                                onClick = { if (vm.streaming) vm.stop() else { vm.send(input); input = "" } },
                                modifier = Modifier.padding(bottom = 4.dp), enabled = canSend || vm.streaming
                            ) {
                                if (vm.streaming) Icon(Icons.Filled.Stop, "Stop generating", tint = Color.White)
                                else Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = if (canSend) Color.White else cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
    if (showModels) ModelSheet(vm, onDismiss = { showModels = false }, openSettings = { showModels = false; openSettings() })
}

@Composable
private fun EmptyState(vm: AppViewModel, openSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        AiOrb(240.dp)
        Spacer(Modifier.height(8.dp))
        Text("RAZA AI ASSISTANT", style = TextStyle(brush = Raza.Brand, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp))
        Spacer(Modifier.height(6.dp))
        Text(vm.tool.blurb, color = cs.onSurfaceVariant, style = TextStyle(textDirection = TextDirection.Content))
        Spacer(Modifier.height(20.dp))
        if (!vm.hasReadyProvider) {
            Card(colors = CardDefaults.cardColors(containerColor = cs.surface.copy(alpha = 0.9f)), border = BorderStroke(1.dp, cs.outline)) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No AI provider connected yet", fontWeight = FontWeight.SemiBold)
                    Text("Add a provider and your own API key to start chatting.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(openSettings) { Text("Add provider") }
                }
            }
        }
    }
}

@Composable
private fun ModelSheet(vm: AppViewModel, onDismiss: () -> Unit, openSettings: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState())) {
            Text("Model", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto model", fontWeight = FontWeight.SemiBold)
                    Text("Chooses by task and file type, and falls back to another provider if one fails.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(vm.settings.autoModel, { checked -> vm.update { copy(autoModel = checked) } })
            }
            if (vm.providers.isEmpty()) {
                Text("No providers yet.", Modifier.padding(vertical = 8.dp))
                Button(openSettings) { Text("Add provider") }
            }
            vm.providers.filter { it.enabled }.forEach { p ->
                Text(p.name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))
                val models = (p.models + p.defaultModel).filter { it.isNotBlank() }.distinct()
                if (models.isEmpty()) Text("No model set. Add one in Settings → Providers.", fontSize = 13.sp)
                models.forEach { m ->
                    val selected = vm.settings.activeProviderId == p.id && vm.settings.activeModel.ifBlank { p.defaultModel } == m
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { vm.selectModel(p.id, m); onDismiss() }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { RadioButton(selected, null); Spacer(Modifier.width(10.dp)); Text(m, fontSize = 14.sp) }
                }
            }
        }
    }
}

@Composable
private fun HistoryDrawer(vm: AppViewModel, onClose: () -> Unit, openSettings: () -> Unit) {
    var renameTarget by remember { mutableStateOf<Chat?>(null) }
    var deleteTarget by remember { mutableStateOf<Chat?>(null) }
    ModalDrawerSheet {
        Column(Modifier.fillMaxHeight()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                AiOrb(48.dp)
                Spacer(Modifier.width(10.dp))
                Text("RAZA AI", style = TextStyle(brush = Raza.Brand, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp))
            }
            Button({ vm.newChat(); onClose() }, Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text("New chat")
            }
            OutlinedTextField(
                value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
                placeholder = { Text("Search conversations") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                val list = vm.filteredChats
                if (list.isEmpty()) item { Text(if (vm.query.isBlank()) "No conversations yet." else "No matches.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(list, key = { it.id }) { c ->
                    NavigationDrawerItem(
                        label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        icon = { Icon(Tool.byId(c.tool).icon, null) },
                        selected = c.id == vm.currentId,
                        onClick = { vm.open(c.id); onClose() },
                        badge = { ChatMenu({ renameTarget = c }, { deleteTarget = c }) }
                    )
                }
            }
            HorizontalDivider()
            NavigationDrawerItem(
                label = { Text("Settings") }, icon = { Icon(Icons.Filled.Settings, null) }, selected = false,
                onClick = { onClose(); openSettings() }, modifier = Modifier.padding(8.dp)
            )
        }
    }
    renameTarget?.let { c ->
        var text by remember(c.id) { mutableStateOf(c.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null }, title = { Text("Rename chat") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ vm.rename(c.id, text); renameTarget = null }) { Text("Save") } },
            dismissButton = { TextButton({ renameTarget = null }) { Text("Cancel") } }
        )
    }
    deleteTarget?.let { c ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null }, title = { Text("Delete chat?") },
            text = { Text("“${c.title}” and its attachments will be permanently deleted from this device.") },
            confirmButton = { TextButton({ vm.delete(c.id); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton({ deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ChatMenu(onRename: () -> Unit, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }, Modifier.size(32.dp)) { Icon(Icons.Filled.MoreVert, "Chat options") }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Rename") }, onClick = { open = false; onRename() }, leadingIcon = { Icon(Icons.Filled.Edit, null) })
            DropdownMenuItem(text = { Text("Delete") }, onClick = { open = false; onDelete() }, leadingIcon = { Icon(Icons.Filled.Delete, null) })
        }
    }
}
